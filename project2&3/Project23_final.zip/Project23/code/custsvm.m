function[svmtestlabel] = custsvm(svtrain,svtest,svtraincl,svtestcl,svmmethod)
trcls=svtraincl';
tscls=svtestcl';
trn=svtrain';
tst=svtest';
if strcmp(svmmethod,'GSN')
    model = svmtrain(trcls, trn, '-s 0 -t 2');
else
    model = svmtrain(trcls, trn, '-s 0 -t 0');
end;
[predict_label, ~, ~]=svmpredict(tscls,tst,model);
svmtestlabel=predict_label';
end